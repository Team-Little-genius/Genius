# 微信小程序：light轻音乐


![播放](./screenshot/2.jpg)
![播放](./screenshot/3.jpg)
![列表](./screenshot/4.jpg)
![分享](./screenshot/5.jpg)